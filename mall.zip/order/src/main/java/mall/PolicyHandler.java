package mall;

import mall.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired
    OrderRepository orderRepository;
    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverShipped_UpdateStatus(@Payload Shipped shipped){

        if(shipped.isMe()){
            System.out.println("##### listener UpdateStatus : " + shipped.toJson());
            System.out.println();
            System.out.println();

            // Coding
            // Optional - findById 의 리턴타입임. not null 처리 가능
            java.util.Optional<Order> orderOptional = orderRepository.findById(shipped.getOrderId());
            Order order = orderOptional.get();

            // Order order = orderRepository.findById(shipped.getOrderId()).orElseThrow(NoSuchElementException::new);

            order.setStatus(shipped.getStatus());
            // findById > save = update 처리 
            orderRepository.save(order);

        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverDeliverCancelled_UpdateStatus(@Payload DeliverCancelled deliverCancelled){

        if(deliverCancelled.isMe()){
            System.out.println("##### listener UpdateStatus : " + deliverCancelled.toJson());
            System.out.println();
            System.out.println();
        }
    }

}
