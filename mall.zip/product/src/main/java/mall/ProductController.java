package mall;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

 @RestController
 public class ProductController {
        @Autowired
        ProductRepository productRepository;

        @RequestMapping(value = "/chkAndModifyStock",
                method = RequestMethod.GET,
                produces = "application/json;charset=UTF-8")

        public boolean modifyStock(HttpServletRequest request, HttpServletResponse response)
                throws Exception {

                // 주문서비스로부터 ProductID 와 qty를 받아서
                // 해당 상품의 재고여부 체크 후, 가/부 를 리턴
                System.out.println("##### /product/modifyStock  called #####");

                boolean status = false;
                Long productId = Long.valueOf(request.getParameter("productId"));
                int qty = Integer.parseInt(request.getParameter("qty"));

                Product product = productRepository.findByProductId(productId);

                if (product.getStock() >= qty) {
                        product.setStock(product.getStock() - qty);
                        productRepository.save(product);
                        status = true;
                }

                return status;
        }

 }
