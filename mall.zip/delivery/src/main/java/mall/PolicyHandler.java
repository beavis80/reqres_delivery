package mall;

import mall.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired
    DeliveryRepository deliveryRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrdered_PrepareShip(@Payload Ordered ordered){

        if(ordered.isMe()){
            // To-Do (process BIZ logics...)

            // CRUD using Delivery Repository
            Delivery delivery = new Delivery();
            delivery.setOrderId(ordered.getId());
            delivery.setStatus("DeliveryStarted");

            // new > save = Create 처리 
            deliveryRepository.save(delivery);

            System.out.println("##### listener PrepareShip : " + ordered.toJson());
            System.out.println();
            System.out.println();
        }
    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrderCancelled_DeleteCancelledOrder(@Payload OrderCancelled orderCancelled){

        if(orderCancelled.isMe()){
            // 주문 취소시 Delivery 삭제 구현
            Delivery delivery = deliveryRepository.findByOrderId(orderCancelled.getId());
            deliveryRepository.delete(delivery);

            //
            System.out.println("##### listener DeleteCancelledOrder : " + orderCancelled.toJson());
            System.out.println();
            System.out.println();
        }
    }

}
