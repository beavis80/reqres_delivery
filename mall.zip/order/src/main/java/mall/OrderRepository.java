package mall;

import org.springframework.data.repository.PagingAndSortingRepository;

// Order aggregate 의 Rest API 처리
// CRUD function 제공
public interface OrderRepository extends PagingAndSortingRepository<Order, Long>{


}